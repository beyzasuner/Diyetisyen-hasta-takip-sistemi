package com.diyetapp.backend.repository;

import com.diyetapp.backend.entity.Dosya;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DosyaRepository extends JpaRepository<Dosya, Long> {
    List<Dosya> findByHastaId(Long hastaId);
}
